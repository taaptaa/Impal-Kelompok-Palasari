import { useEffect, useState } from 'react';
import { RoleSelectionScreen } from './screens/RoleSelectionScreen';
import { LoginScreen } from './screens/LoginScreen';
import { MainApp } from './screens/MainApp';
import { User, UserRole } from './types';
import { Toaster, toast } from 'sonner';
export default function App() {
 const [user,setUser]=useState<User|null>(null),[role,setRole]=useState<UserRole|null>(null),[loading,setLoading]=useState(true);
 useEffect(()=>{fetch('/api/me').then(r=>r.ok?r.json():null).then(d=>{if(d)setUser(d.user);}).catch(()=>toast.error('Server tidak dapat dihubungi.')).finally(()=>setLoading(false));},[]);
 async function logout(){try{const current=await fetch('/api/me');if(current.status===401){setUser(null);setRole(null);return;}
 const data=await current.json();const r=await fetch('/api/logout',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF-Token':data.csrf},body:'{}'});if(!r.ok)throw Error();setUser(null);setRole(null);}catch{toast.error('Logout gagal. Coba kembali.');}}
 if(loading)return <p style={{padding:40}}>Memeriksa sesi...</p>;
 return <><Toaster position="top-center" richColors />
 {user ? <><div style={{background:'#fff8e6',padding:'10px 24px',fontSize:13}}>Sprint 1: login terhubung database. Fitur bisnis di bawah masih prototipe data lokal. <button onClick={logout} style={{float:"right",fontWeight:700}}>Keluar sesi</button></div><MainApp user={user} onLogout={logout}/></> : role ? <LoginScreen selectedRole={role} onLogin={setUser} onBack={()=>setRole(null)}/> : <RoleSelectionScreen onSelectRole={(r,a)=>{if(a==='register'){toast.info('Registrasi di luar Sprint 1. Gunakan akun demo terdaftar.');return;}setRole(r);}}/>}
 </>;
}
