-- Baseline Week 5 + ekstensi Week 6. SQLite adalah profil demo yang diuji.
CREATE TABLE IF NOT EXISTS pengguna (
    id_pengguna INT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    peran VARCHAR(15) NOT NULL,
    aktif INT NOT NULL DEFAULT 1 CHECK (aktif IN (0,1)),
    CHECK (peran IN ('mahasiswa','admin','petugas'))
 );

CREATE TABLE IF NOT EXISTS ruangan (
    id_ruangan INT PRIMARY KEY,
    kode_ruangan VARCHAR(20) NOT NULL UNIQUE,
    nama_ruangan VARCHAR(80) NOT NULL,
    kapasitas INT NOT NULL CHECK (kapasitas > 0),
    lokasi VARCHAR(100) NOT NULL,
    status_operasional VARCHAR(15) NOT NULL,
    CHECK (status_operasional IN ('aktif','perawatan'))
 );

CREATE TABLE IF NOT EXISTS barang (
    id_barang INT PRIMARY KEY,
    kode_barang VARCHAR(20) NOT NULL UNIQUE,
    nama_barang VARCHAR(80) NOT NULL,
    jenis VARCHAR(15) NOT NULL,
    satuan VARCHAR(20) NOT NULL,
    stok_total INT NOT NULL CHECK (stok_total >= 0),
    CHECK (jenis IN ('portabel','tetap'))
 );

CREATE TABLE IF NOT EXISTS fasilitas_ruangan (
    id_ruangan INT NOT NULL,
    id_barang INT NOT NULL,
    jumlah INT NOT NULL CHECK (jumlah > 0),
    PRIMARY KEY (id_ruangan, id_barang),
    FOREIGN KEY (id_ruangan) REFERENCES ruangan(id_ruangan),
    FOREIGN KEY (id_barang) REFERENCES barang(id_barang)
 );

CREATE TABLE IF NOT EXISTS peminjaman (
    id_peminjaman INT PRIMARY KEY,
    kode_peminjaman VARCHAR(25) NOT NULL UNIQUE,
    id_peminjam INT NOT NULL,
    id_admin INT,
    waktu_mulai DATETIME NOT NULL,
    waktu_selesai DATETIME NOT NULL,
    keperluan VARCHAR(150) NOT NULL,
    status VARCHAR(15) NOT NULL,
    CHECK (waktu_selesai > waktu_mulai),
    CHECK (status IN ('menunggu','disetujui','ditolak',
                      'dipinjam','selesai','dibatalkan')),
    FOREIGN KEY (id_peminjam) REFERENCES pengguna(id_pengguna),
    FOREIGN KEY (id_admin) REFERENCES pengguna(id_pengguna)
 );

CREATE TABLE IF NOT EXISTS detail_barang (
   id_peminjaman INT NOT NULL,
   id_barang INT NOT NULL,
   jumlah INT NOT NULL CHECK (jumlah > 0),
   PRIMARY KEY (id_peminjaman, id_barang),
   FOREIGN KEY (id_peminjaman)
      REFERENCES peminjaman(id_peminjaman),
      FOREIGN KEY (id_barang) REFERENCES barang(id_barang)
 );

CREATE TABLE IF NOT EXISTS detail_ruangan (
    id_peminjaman INT PRIMARY KEY,
    id_ruangan INT NOT NULL,
    jumlah_peserta INT NOT NULL CHECK (jumlah_peserta > 0),
    FOREIGN KEY (id_peminjaman)
       REFERENCES peminjaman(id_peminjaman),
    FOREIGN KEY (id_ruangan) REFERENCES ruangan(id_ruangan)
 );

CREATE TABLE IF NOT EXISTS pengembalian (
    id_pengembalian INT PRIMARY KEY,
    id_peminjaman INT NOT NULL UNIQUE,
    id_petugas INT NOT NULL,
    waktu_kembali DATETIME NOT NULL,
    kondisi_akhir VARCHAR(15) NOT NULL,
    catatan VARCHAR(200) NOT NULL,
    CHECK (kondisi_akhir IN ('baik','rusak','hilang')),
    FOREIGN KEY (id_peminjaman)
       REFERENCES peminjaman(id_peminjaman),
    FOREIGN KEY (id_petugas) REFERENCES pengguna(id_pengguna)
 );

CREATE TABLE IF NOT EXISTS rekomendasi_ai (
    id_rekomendasi INT PRIMARY KEY,
    id_pengguna INT NOT NULL,
    kebutuhan VARCHAR(200) NOT NULL,
    id_ruangan INT,
    id_barang INT,
    alasan VARCHAR(250) NOT NULL,
    dibuat_pada DATETIME NOT NULL,
    CHECK (id_ruangan IS NOT NULL OR id_barang IS NOT NULL),
    FOREIGN KEY (id_pengguna) REFERENCES pengguna(id_pengguna),
    FOREIGN KEY (id_ruangan) REFERENCES ruangan(id_ruangan),
    FOREIGN KEY (id_barang) REFERENCES barang(id_barang)
 );
CREATE TABLE IF NOT EXISTS sesi (
 token_hash VARCHAR(64) PRIMARY KEY, id_pengguna INT NOT NULL,
 csrf VARCHAR(48) NOT NULL, expires_at BIGINT NOT NULL,
 FOREIGN KEY(id_pengguna) REFERENCES pengguna(id_pengguna)
);
CREATE TABLE IF NOT EXISTS percobaan_login (
 email VARCHAR(100) PRIMARY KEY, jumlah INT NOT NULL,
 locked_until BIGINT NOT NULL, updated_at BIGINT NOT NULL
);
CREATE TABLE IF NOT EXISTS notifikasi (
 id_notifikasi INT PRIMARY KEY, id_pengguna INT NOT NULL,
 id_peminjaman INT NOT NULL, pesan VARCHAR(500) NOT NULL,
 dibuat_pada DATETIME NOT NULL, dibaca INT NOT NULL DEFAULT 0 CHECK(dibaca IN (0,1)),
 FOREIGN KEY(id_pengguna) REFERENCES pengguna(id_pengguna),
 FOREIGN KEY(id_peminjaman) REFERENCES peminjaman(id_peminjaman)
);
CREATE TABLE IF NOT EXISTS detail_pengembalian (
 id_pengembalian INT NOT NULL, id_barang INT NOT NULL,
 jumlah_baik INT NOT NULL CHECK(jumlah_baik >= 0),
 jumlah_rusak INT NOT NULL CHECK(jumlah_rusak >= 0),
 jumlah_hilang INT NOT NULL CHECK(jumlah_hilang >= 0),
 PRIMARY KEY(id_pengembalian,id_barang),
 FOREIGN KEY(id_pengembalian) REFERENCES pengembalian(id_pengembalian),
 FOREIGN KEY(id_barang) REFERENCES barang(id_barang),
 CHECK(jumlah_baik + jumlah_rusak + jumlah_hilang > 0)
);

CREATE TABLE IF NOT EXISTS feedback (
 id_feedback INT PRIMARY KEY, id_pengguna INT NOT NULL,
 id_peminjaman INT NOT NULL UNIQUE, rating INT NOT NULL CHECK(rating BETWEEN 1 AND 5),
 komentar VARCHAR(500) NOT NULL,
 FOREIGN KEY(id_pengguna) REFERENCES pengguna(id_pengguna),
 FOREIGN KEY(id_peminjaman) REFERENCES peminjaman(id_peminjaman)
);
