// Optional: npm install --no-save playwright; npx playwright install chromium
// Run from SmartLend root: node tests/browser.cjs (stop any existing server first).
const {chromium}=require('playwright');
const fs=require('fs');
(async()=>{const server=require('child_process').spawn(process.execPath,['backend/server.mjs'],{cwd:process.cwd()}); await new Promise(r=>server.stdout.once('data',r)); const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH || undefined,args:['--no-sandbox']});const page=await browser.newPage({viewport:{width:1365,height:1000}});const errors=[];page.on('pageerror',e=>errors.push(e.message));await page.goto('http://127.0.0.1:3000');await page.screenshot({path:'evidence/01-role.png',fullPage:true});await page.getByRole('button',{name:/Mahasiswa/}).click();
await page.locator('input[type=email]').fill('mahasiswa@smartlend.test');await page.getByRole('button',{name:'Lanjutkan'}).click();
await page.locator('input[type=password]').fill('salah');await page.getByRole('button',{name:'Masuk',exact:true}).click();await page.getByRole('alert').waitFor();await page.screenshot({path:'evidence/02-login-error.png',fullPage:true});
await page.locator('input[type=password]').fill('SmartLend!2026');await page.screenshot({path:'evidence/03-login.png',fullPage:true});await page.getByRole('button',{name:'Masuk',exact:true}).click();await page.getByText('Sprint 1: login terhubung database.',{exact:false}).waitFor();await page.screenshot({path:'evidence/04-success.png',fullPage:false});
await page.reload();await page.getByText('Sprint 1: login terhubung database.',{exact:false}).waitFor();
await page.getByRole('button',{name:'Keluar sesi',exact:true}).first().click();await page.getByRole('button',{name:/Mahasiswa/}).waitFor();await page.screenshot({path:'evidence/05-logout.png',fullPage:true});
fs.writeFileSync('evidence/browser-results.json',JSON.stringify({login:true,invalidPassword:true,refresh:true,logout:true,consoleErrors:errors},null,2));
await browser.close();server.kill();})();
