import {test} from 'node:test';
import assert from 'node:assert/strict';
import {Barang,Ruangan,Peminjaman,DetailPengembalian,RekomendasiAI} from '../backend/domain.ts';
test('21 stok negatif ditolak',()=>assert.throws(()=>new Barang(1,'B','Mic','portabel','unit',-1).validasi()));
test('22 ruang perawatan dan kapasitas berlebih ditolak',()=>{assert.equal(new Ruangan(1,'R','Ruang',30,'A','aktif').dapatMenampung(31),false);assert.equal(new Ruangan(1,'R','Ruang',30,'A','perawatan').dapatMenampung(20),false);});
test('23 interval dan transisi peminjaman',()=>{const p=new Peminjaman(1,'P',1,null,new Date('2026-10-28T09:00:00Z'),new Date('2026-10-28T10:00:00Z'),'Rapat','menunggu');p.validasiInterval();assert.throws(()=>p.transisi('selesai'));p.transisi('disetujui');p.transisi('dipinjam');p.transisi('selesai');assert.equal(p.getStatus(),'selesai');});
test('24 jumlah kondisi pengembalian harus sama dengan jumlah dipinjam',()=>{const d=new DetailPengembalian(1,1,2,1,0);d.validasi(3);assert.throws(()=>d.validasi(4));});
test('25 rekomendasi harus memiliki target',()=>assert.throws(()=>new RekomendasiAI(1,1,'rapat',null,null,'test',new Date()).validasiTarget()));
