// Domain Week 6. Nilai privat; persistence bisnis belum diimplementasikan.
export type JenisBarang = 'portabel' | 'tetap';
export type StatusRuang = 'aktif' | 'perawatan';
export type Kondisi = 'baik' | 'rusak' | 'hilang';
export type StatusPinjam = 'menunggu'|'disetujui'|'ditolak'|'dipinjam'|'selesai'|'dibatalkan';

export class Barang {
  private id: number;
  private kode: string;
  private nama: string;
  private jenis: JenisBarang;
  private satuan: string;
  private stokTotal: number;
  constructor(id: number, kode: string, nama: string, jenis: JenisBarang, satuan: string, stokTotal: number) {
    this.id=id;
    this.kode=kode;
    this.nama=nama;
    this.jenis=jenis;
    this.satuan=satuan;
    this.stokTotal=stokTotal;
  }
  public isPortabel(): boolean { return this.jenis === "portabel"; }
  public validasi(): void { if (!Number.isInteger(this.stokTotal) || this.stokTotal < 0) throw new Error("Stok tidak valid"); }
}

export class Ruangan {
  private id: number;
  private kode: string;
  private nama: string;
  private kapasitas: number;
  private lokasi: string;
  private status: StatusRuang;
  constructor(id: number, kode: string, nama: string, kapasitas: number, lokasi: string, status: StatusRuang) {
    this.id=id;
    this.kode=kode;
    this.nama=nama;
    this.kapasitas=kapasitas;
    this.lokasi=lokasi;
    this.status=status;
  }
  public dapatMenampung(peserta: number): boolean { return Number.isInteger(peserta) && peserta > 0 && peserta <= this.kapasitas && this.status === "aktif"; }
}

export class FasilitasRuangan {
  private ruanganId: number;
  private barangId: number;
  private jumlah: number;
  constructor(ruanganId: number, barangId: number, jumlah: number) {
    this.ruanganId=ruanganId;
    this.barangId=barangId;
    this.jumlah=jumlah;
  }
  public validasi(): void { if (!Number.isInteger(this.jumlah) || this.jumlah < 1) throw new Error("Jumlah harus positif"); }
}

export class Peminjaman {
  private id: number;
  private kode: string;
  private peminjamId: number;
  private adminId: number|null;
  private mulai: Date;
  private selesai: Date;
  private keperluan: string;
  private status: StatusPinjam;
  constructor(id: number, kode: string, peminjamId: number, adminId: number|null, mulai: Date, selesai: Date, keperluan: string, status: StatusPinjam) {
    this.id=id;
    this.kode=kode;
    this.peminjamId=peminjamId;
    this.adminId=adminId;
    this.mulai=mulai;
    this.selesai=selesai;
    this.keperluan=keperluan;
    this.status=status;
  }
  public validasiInterval(): void { if (!Number.isFinite(this.mulai.getTime()) || !Number.isFinite(this.selesai.getTime()) || this.selesai <= this.mulai) throw new Error("Interval tidak valid"); }
  public transisi(target: StatusPinjam): void { const next: Record<StatusPinjam, StatusPinjam[]> = {menunggu:["disetujui","ditolak","dibatalkan"],disetujui:["dipinjam","dibatalkan"],dipinjam:["selesai"],ditolak:[],dibatalkan:[],selesai:[]}; if (!next[this.status].includes(target)) throw new Error("Transisi ditolak"); this.status=target; }
  public getStatus(): StatusPinjam { return this.status; }
}

export class DetailBarang {
  private peminjamanId: number;
  private barangId: number;
  private jumlah: number;
  constructor(peminjamanId: number, barangId: number, jumlah: number) {
    this.peminjamanId=peminjamanId;
    this.barangId=barangId;
    this.jumlah=jumlah;
  }
  public validasi(): void { if (!Number.isInteger(this.jumlah) || this.jumlah <= 0) throw new Error("Jumlah harus positif"); }
}

export class DetailRuangan {
  private peminjamanId: number;
  private ruanganId: number;
  private jumlahPeserta: number;
  constructor(peminjamanId: number, ruanganId: number, jumlahPeserta: number) {
    this.peminjamanId=peminjamanId;
    this.ruanganId=ruanganId;
    this.jumlahPeserta=jumlahPeserta;
  }
  public validasiKapasitas(ruang: Ruangan): boolean { return ruang.dapatMenampung(this.jumlahPeserta); }
}

export class Pengembalian {
  private id: number;
  private peminjamanId: number;
  private petugasId: number;
  private waktuKembali: Date;
  private kondisiAkhir: Kondisi;
  private catatan: string;
  constructor(id: number, peminjamanId: number, petugasId: number, waktuKembali: Date, kondisiAkhir: Kondisi, catatan: string) {
    this.id=id;
    this.peminjamanId=peminjamanId;
    this.petugasId=petugasId;
    this.waktuKembali=waktuKembali;
    this.kondisiAkhir=kondisiAkhir;
    this.catatan=catatan;
  }
  public terlambat(batas: Date): boolean { return this.waktuKembali > batas; }
}

export class DetailPengembalian {
  private pengembalianId: number;
  private barangId: number;
  private jumlahBaik: number;
  private jumlahRusak: number;
  private jumlahHilang: number;
  constructor(pengembalianId: number, barangId: number, jumlahBaik: number, jumlahRusak: number, jumlahHilang: number) {
    this.pengembalianId=pengembalianId;
    this.barangId=barangId;
    this.jumlahBaik=jumlahBaik;
    this.jumlahRusak=jumlahRusak;
    this.jumlahHilang=jumlahHilang;
  }
  public validasi(jumlahDipinjam: number): void { const values=[this.jumlahBaik,this.jumlahRusak,this.jumlahHilang]; if(values.some(n=>!Number.isInteger(n)||n<0)||values.reduce((a,b)=>a+b,0)!==jumlahDipinjam||jumlahDipinjam<=0) throw new Error("Jumlah pengembalian tidak sesuai"); }
}

export class RekomendasiAI {
  private id: number;
  private penggunaId: number;
  private kebutuhan: string;
  private ruanganId: number|null;
  private barangId: number|null;
  private alasan: string;
  private dibuatPada: Date;
  constructor(id: number, penggunaId: number, kebutuhan: string, ruanganId: number|null, barangId: number|null, alasan: string, dibuatPada: Date) {
    this.id=id;
    this.penggunaId=penggunaId;
    this.kebutuhan=kebutuhan;
    this.ruanganId=ruanganId;
    this.barangId=barangId;
    this.alasan=alasan;
    this.dibuatPada=dibuatPada;
  }
  public validasiTarget(): void { if(this.ruanganId===null && this.barangId===null) throw new Error("Target wajib ada"); }
}

export class Notifikasi {
  private id: number;
  private penggunaId: number;
  private peminjamanId: number;
  private pesan: string;
  private dibuatPada: Date;
  private dibaca: boolean;
  constructor(id: number, penggunaId: number, peminjamanId: number, pesan: string, dibuatPada: Date, dibaca: boolean) {
    this.id=id;
    this.penggunaId=penggunaId;
    this.peminjamanId=peminjamanId;
    this.pesan=pesan;
    this.dibuatPada=dibuatPada;
    this.dibaca=dibaca;
  }
  public tandaiDibaca(): void { this.dibaca=true; }
}

export class Feedback {
  private id: number;
  private penggunaId: number;
  private peminjamanId: number;
  private rating: number;
  private komentar: string;
  constructor(id: number, penggunaId: number, peminjamanId: number, rating: number, komentar: string) {
    this.id=id;
    this.penggunaId=penggunaId;
    this.peminjamanId=peminjamanId;
    this.rating=rating;
    this.komentar=komentar;
  }
  public validasiRating(): void { if(!Number.isInteger(this.rating)||this.rating<1||this.rating>5) throw new Error("Rating harus 1 sampai 5"); }
}

// Batas sprint: kontrak service berikut belum memiliki adapter database/HTTP.
export interface PeminjamanService {
  ajukan(data: Peminjaman, barang: DetailBarang[], ruang: DetailRuangan|null): Promise<number>;
  setujui(id: number, adminId: number): Promise<void>;
  serahkan(id: number, petugasId: number): Promise<void>;
}
export interface PengembalianService {
  proses(data: Pengembalian, detail: DetailPengembalian[]): Promise<void>;
}
export interface RekomendasiService {
  rekomendasikan(kebutuhan: string, mulai: Date, selesai: Date): Promise<RekomendasiAI[]>;
}
