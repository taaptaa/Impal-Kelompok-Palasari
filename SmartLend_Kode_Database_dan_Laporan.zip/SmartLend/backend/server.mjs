import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import { pathToFileURL } from 'node:url';
import { openDb,root } from './db.mjs';
import { AuthService } from './auth.mjs';
export function makeServer(db,origin='http://127.0.0.1:3000') {
 const auth=new AuthService(db),dist=resolve(root,'frontend/dist');
 return createServer(async(req,res)=>{
  res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('X-Frame-Options','DENY');
  const send=(status,data)=>{res.writeHead(status,{'Content-Type':'application/json'});res.end(JSON.stringify(data));};
  const token=(req.headers.cookie||'').match(/(?:^|;\s*)sid=([a-f0-9]{64})(?:;|$)/)?.[1] || '';
  const path=new URL(req.url,origin).pathname;
  try {
   if(path.startsWith('/api/')) {
    if(req.method==='GET'&&path==='/api/me') {const data=auth.current(token);return send(data?200:401,data || {error:'Silakan login.'});}
    if(req.method==='GET'&&path==='/api/admin') {const data=auth.current(token);return send(!data?401:data.user.role==='admin'?200:403,!data?{error:'Silakan login.'}:data.user.role==='admin'?{message:'Akses admin terverifikasi.'}:{error:'Akses ditolak.'});}
    if(req.method!=='POST') return send(404,{error:'Endpoint tidak ditemukan.'});
    if(req.headers.origin!==origin || !(req.headers['content-type']||'').startsWith('application/json')) return send(403,{error:'Origin atau format permintaan tidak diizinkan.'});
    let body='';for await(const chunk of req){body+=chunk;if(body.length>4096)return send(413,{error:'Permintaan terlalu besar.'});}
    let input;try{input=JSON.parse(body);}catch{return send(400,{error:'JSON tidak valid.'});}
    if(!input||typeof input!=='object'||Array.isArray(input))return send(400,{error:'Payload harus berupa objek.'});
    const cookie=`Path=/; HttpOnly; SameSite=Strict${origin.startsWith('https:')?'; Secure':''}`;
    if(path==='/api/login'){ const result=auth.login(input.email,input.password,input.role,token);res.setHeader('Set-Cookie',`sid=${result.token}; Max-Age=3600; ${cookie}`);return send(200,{user:result.user,csrf:result.csrf}); }
    if(path==='/api/logout'){const current=auth.current(token);if(!current)return send(401,{error:'Silakan login.'});if(req.headers['x-csrf-token']!==current.csrf)return send(403,{error:'CSRF tidak valid.'});auth.logout(token);res.setHeader('Set-Cookie',`sid=; Max-Age=0; ${cookie}`);return send(200,{ok:true});}
    return send(404,{error:'Endpoint tidak ditemukan.'});
   }
   if(req.method!=='GET')return send(405,{error:'Metode tidak diizinkan.'});
   const file=resolve(dist,'.'+decodeURIComponent(path));if(!file.startsWith(dist+'/')&&file!==dist)return send(403,{error:'Akses ditolak.'});
   let data; let extension=extname(file);try{data=await readFile(file);}catch{data=await readFile(dist+'/index.html');extension='.html';}
   res.writeHead(200,{'Content-Type':({'.html':'text/html; charset=utf-8','.js':'application/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml'})[extension]||'application/octet-stream'});res.end(data);
  }catch(e){send(e.status||500,{error:e.status?e.message:'Kesalahan internal server.'});}
 });
}
if(import.meta.url===pathToFileURL(process.argv[1]).href){const port=Number(process.env.PORT||3000),origin=process.env.APP_ORIGIN||`http://127.0.0.1:${port}`;makeServer(openDb(),origin).listen(port,'127.0.0.1',()=>console.log(`SmartLend: ${origin}`));}
