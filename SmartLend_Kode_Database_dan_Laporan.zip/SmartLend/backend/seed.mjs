import { openDb } from './db.mjs';
import { PasswordHasher } from './auth.mjs';
export function seed(db) { const hasher=new PasswordHasher();for(const [id,nama,email,peran] of [[1,'Mahasiswa Demo','mahasiswa@smartlend.test','mahasiswa'],[2,'Admin Demo','admin@smartlend.test','admin'],[3,'Petugas Demo','petugas@smartlend.test','petugas']]) db.prepare('INSERT OR IGNORE INTO pengguna(id_pengguna,nama,email,password_hash,peran,aktif) VALUES(?,?,?,?,?,1)').run(id,nama,email,hasher.hash('SmartLend!2026'),peran); }
if(process.argv[1]?.endsWith('seed.mjs')) {const db=openDb();seed(db);db.close();console.log('3 akun demo siap. Password lokal: SmartLend!2026');}
