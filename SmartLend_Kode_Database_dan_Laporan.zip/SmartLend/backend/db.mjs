import { DatabaseSync } from 'node:sqlite';
import { readFileSync, mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
export const root=fileURLToPath(new URL('../',import.meta.url));
export function openDb(path=process.env.DB_PATH || root+'database/smartlend.sqlite') {mkdirSync(root+'database',{recursive:true});const db=new DatabaseSync(path);db.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL;');db.exec(readFileSync(root+'database/schema.sqlite.sql','utf8'));return db;}
