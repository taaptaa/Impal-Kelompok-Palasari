# SmartLend - Week 6 dan Sprint 1

Kelompok Palasari, IF-48-01. Implementasi lanjutan sumber React Week 4.

## Menjalankan demo login (Node.js 24 atau lebih baru)

1. Ekstrak ZIP, buka terminal di folder SmartLend.
2. Jalankan `npm run seed` (akun contoh; tidak menimpa akun yang sudah ada).
3. Jalankan `npm start`.
4. Buka **http://127.0.0.1:3000**. Gunakan alamat persis ini, bukan localhost, karena pemeriksaan origin.

`frontend/dist` sudah disertakan sehingga demo tidak memerlukan npm install.
Untuk mengubah UI: `npm --prefix frontend ci`, lalu `npm run build` dan mulai ulang server.
Backend memakai modul bawaan Node.js; tidak membutuhkan dependensi tambahan.

| Pilihan UI | Email | Password demo |
|---|---|---|
| Mahasiswa | mahasiswa@smartlend.test | SmartLend!2026 |
| Admin | admin@smartlend.test | SmartLend!2026 |
| Logistik | petugas@smartlend.test | SmartLend!2026 |

Akun adalah data fiktif untuk demo lokal. Peran ditentukan database, pilihan UI hanya diverifikasi.
Sesi berlaku satu jam, dipulihkan setelah refresh, dan dihapus saat logout. Setelah lima percobaan gagal pada email sama, akun dibatasi selama 15 menit.

## Status implementasi

- Selesai dan diuji: UI login React, database SQLite persisten, scrypt, tiga peran, sesi HttpOnly, pemulihan sesi, logout, CSRF logout, validasi origin, pembatasan percobaan, endpoint admin untuk bukti otorisasi.
- Kelas domain TypeScript: atribut privat, tipe, metode validasi dan transisi status; belum dihubungkan ke transaksi bisnis HTTP/database.
- Katalog, peminjaman, approval, QR, pengembalian dan notifikasi pada layar lama masih prototipe/mock; banner menyatakan batas ini.
- Ruangan, rekomendasi AI, tiket PDF dan proses persetujuan atomik: rancangan Sprint 2/3; belum diklaim berfungsi end-to-end.
- Registrasi mock tidak dapat dipakai untuk masuk.

## Database dan perubahan teknologi

Week 1 merencanakan Laravel/MySQL; Week 4 menyediakan React/Vite. Paket ini mempertahankan React dan memilih backend Node.js 24 + SQLite agar login dapat didemonstrasikan tanpa layanan database eksternal. Ini perubahan arsitektur yang perlu dicatat pada DPPL.
`schema.sqlite.sql` adalah skema demo yang telah dijalankan. `schema.mysql.sql` adalah rancangan target MySQL 8.0.16+, belum diuji di server MySQL. Backend ini tidak memiliki adapter MySQL; menjalankan DDL MySQL saja tidak mengganti koneksi backend.
Skema memiliki 14 tabel. Tiga akun demo saja di-seed; data contoh bisnis Week 5 tidak otomatis diimpor.
`database/smartlend.sqlite` berisi akun demo tanpa sesi aktif saat dikemas. Hapus file database lokal dan jalankan seed jika memerlukan reset data demo (jangan lakukan pada data nyata).

## Pengujian

`npm test` menjalankan 25 pengujian otomatis API, autentikasi, constraint dan domain dengan database memori terisolasi. Bukti eksekusi ada di evidence/tests.tap.
Pengujian browser dan screenshot ada di evidence/. Script browser memerlukan Playwright dan browser Chromium terpasang; ini dependensi pengujian opsional, bukan syarat menjalankan demo.

## Batas penggunaan

Demo diikat ke 127.0.0.1. Untuk deployment sungguhan diperlukan HTTPS, pengelolaan akun/secret, rate limiting tingkat jaringan, logging terkontrol, backup, serta pengujian keamanan dan konkurensi. Cookie Secure otomatis aktif bila APP_ORIGIN menggunakan HTTPS, tetapi TLS harus disediakan reverse proxy.
Dokumen `frontend/legacy-docs` berasal dari paket lama, bukan bukti backend bisnis sudah selesai.

## Berkas utama

- backend/auth.mjs: Pengguna, PasswordHasher, UserRepository, SessionRepository, AuthService.
- backend/server.mjs: routing HTTP, guard origin, sesi dan akses admin.
- backend/domain.ts: 11 kelas domain dan 3 kontrak service untuk sprint berikutnya.
- database/: profil SQL dan database demo.
- docs/: diagram, katalog kelas, dan laporan.
- evidence/: hasil uji dan screenshot asli eksekusi.

Pengembangan dibantu AI untuk evaluasi desain, konversi kelas, implementasi dan pengujian. Anggota kelompok tetap perlu mempelajari kode dan mendemonstrasikan hasil. Tidak ada klaim persetujuan asisten/dosen atau aktivitas rapat yang belum dilakukan.
